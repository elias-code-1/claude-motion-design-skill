# STYLE REPORT — Paresseux Version Courte (Kinetic Sombre)

- **Identifiant vidéo** : `09c9b5a9-aa00-4c1a-bb9d-a7fa10dcd6e5`
- **Cluster de style associé** : `kinetic-sombre`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 28.1s
- **Nombre de coupes (cuts)** : 10
- **Rythme moyen** : 2.6s par plan

## 2. Palette de Couleurs
- `#0D1B2A (Fond nuit)`
- `#C0392B (Rouge trait)`
- `#2D6A8F (Teal)`
- `#F5F5F5 (Blanc)`

## 3. Typographie
- **Famille recommandée** : Inter 900 + Playfair Display (pour les phrases poétiques)
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Effet strike-through animé, timer cercle de 2 minutes, transition fade-blur

## 5. Sound Design & Narration
- Son de trait barré, basse sourde, voix posée intime
