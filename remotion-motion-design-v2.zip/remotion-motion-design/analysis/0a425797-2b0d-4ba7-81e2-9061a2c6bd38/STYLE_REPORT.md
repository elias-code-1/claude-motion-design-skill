# STYLE REPORT — Café Paris Lomé Restaurant & App (Logo Luxe)

- **Identifiant vidéo** : `0a425797-2b0d-4ba7-81e2-9061a2c6bd38`
- **Cluster de style associé** : `logo-luxe`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 16:9 (1024x576)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 28.1s
- **Nombre de coupes (cuts)** : 4
- **Rythme moyen** : 5.6s par plan

## 2. Palette de Couleurs
- `#1A0A1E (Bordeaux nuit)`
- `#C0143C (Carmin)`
- `#FFFFFF (Blanc)`
- `#F5A0B5 (Rosé)`

## 3. Typographie
- **Famille recommandée** : Playfair Display / Cinzel (Logo) + Plus Jakarta Sans (App)
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Tracé calligraphique du logo, halo lumineux, mockup téléphone élégant

## 5. Sound Design & Narration
- Musique lounge/jazzy de restaurant, cliquetis verres, VO chaleureuse
