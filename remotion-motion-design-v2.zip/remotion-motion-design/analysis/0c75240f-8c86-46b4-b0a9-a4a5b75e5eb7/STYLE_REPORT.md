# STYLE REPORT — aLance SaaS Explainer (Corporate Blanc)

- **Identifiant vidéo** : `0c75240f-8c86-46b4-b0a9-a4a5b75e5eb7`
- **Cluster de style associé** : `saas-clair-fr`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 16:9 (1024x576)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 39.0s
- **Nombre de coupes (cuts)** : 2
- **Rythme moyen** : 13.0s par plan

## 2. Palette de Couleurs
- `#F0F4F8 (Fond)`
- `#2563EB (Primaire)`
- `#22C55E (Accent)`
- `#111827 (Texte)`

## 3. Typographie
- **Famille recommandée** : Plus Jakarta Sans / Inter - Black 800 pour titres, regular pour descriptions
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Entrées expo-out douces, zoom caméra 1.05x, fond grille animée avec blobs pastel floutés

## 5. Sound Design & Narration
- Tapis corporate synthé discret, VO chaleureuse ~130 mots/min, SFX pop/whoosh
