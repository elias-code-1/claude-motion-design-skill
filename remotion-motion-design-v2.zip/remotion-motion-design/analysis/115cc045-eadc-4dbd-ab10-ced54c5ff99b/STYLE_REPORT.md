# STYLE REPORT — Calus Smart WhatsApp DM (Énergie Vert)

- **Identifiant vidéo** : `115cc045-eadc-4dbd-ab10-ced54c5ff99b`
- **Cluster de style associé** : `energie-vert`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 16.0s
- **Nombre de coupes (cuts)** : 6
- **Rythme moyen** : 2.3s par plan

## 2. Palette de Couleurs
- `#2D7D1A (Vert foncé)`
- `#7FC043 (Vert flash)`
- `#FFFFFF (Texte)`
- `#113815 (Fond)`

## 3. Typographie
- **Famille recommandée** : Poppins / Montserrat - ExtraBold majuscules, impact visuel fort
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Particules bokeh flottantes, pop 3D de bulles message avec spring vif, tremblement

## 5. Sound Design & Narration
- BPM rapide ~125, SFX notifications WhatsApp, whoosh dynamiques
