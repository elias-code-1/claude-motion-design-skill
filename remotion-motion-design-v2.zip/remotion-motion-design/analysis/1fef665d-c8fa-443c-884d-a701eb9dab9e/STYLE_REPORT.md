# STYLE REPORT — Café Paris Teaser Cinématique (Logo Luxe)

- **Identifiant vidéo** : `1fef665d-c8fa-443c-884d-a701eb9dab9e`
- **Cluster de style associé** : `logo-luxe`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 16:9 (1024x576)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 28.1s
- **Nombre de coupes (cuts)** : 6
- **Rythme moyen** : 4.0s par plan

## 2. Palette de Couleurs
- `#0D0205 (Noir absolu)`
- `#9B1A2A (Bordeaux sang)`
- `#FFFFFF (Blanc pur)`

## 3. Typographie
- **Famille recommandée** : Cormorant Garamond / Bodoni - Lettrages espacés majuscules CUISINE / RESTAURANT
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Révélation progressive par masque circulaire, zoom ultra lent, particules dorées

## 5. Sound Design & Narration
- Riser cinématique, nappe de violoncelles, impact étouffé
