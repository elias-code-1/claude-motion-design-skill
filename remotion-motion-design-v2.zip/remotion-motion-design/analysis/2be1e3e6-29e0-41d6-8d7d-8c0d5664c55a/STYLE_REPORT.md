# STYLE REPORT — Motivation Paresseux (Kinetic Sombre)

- **Identifiant vidéo** : `2be1e3e6-29e0-41d6-8d7d-8c0d5664c55a`
- **Cluster de style associé** : `kinetic-sombre`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 45.0s
- **Nombre de coupes (cuts)** : 2
- **Rythme moyen** : 15.0s par plan

## 2. Palette de Couleurs
- `#0D1B2A (Bleu nuit profond)`
- `#C0392B (Rouge)`
- `#2D6A8F (Teal)`
- `#F5F5F5 (Texte)`

## 3. Typographie
- **Famille recommandée** : Inter / Syne - Black 900 massif, barre de mot barré (strikethrough), italique expressive
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Défilement lent, micro-particules d'étoiles cosmiques, blobs nébuleux, pas de transitions brusques

## 5. Sound Design & Narration
- Ambiance piano mélancolique ou drone ciné, voix off lente ~105 mots/min, intime
