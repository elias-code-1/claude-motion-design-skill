# STYLE REPORT — Kontra Africa Desktop (Illustration Boutique)

- **Identifiant vidéo** : `2e6c92d6-1497-4d62-aefc-cf1dfaea8db3`
- **Cluster de style associé** : `illustration-boutique`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 16:9 (1024x576)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 66.9s
- **Nombre de coupes (cuts)** : 10
- **Rythme moyen** : 6.1s par plan

## 2. Palette de Couleurs
- `#F0F5F0 (Beige-vert clair)`
- `#1A5C3A (Vert forêt)`
- `#F5C518 (Jaune soleil)`
- `#111827 (Noir)`

## 3. Typographie
- **Famille recommandée** : Plus Jakarta Sans 800 - Badges FCFA, montants lisibles
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Illustration flat animée de boutique, smartphone affichant les ventes, pastilles flottantes

## 5. Sound Design & Narration
- Boutique ambiante, SFX caisse enregistreuse 'cha-ching', VO accent africain dynamique
