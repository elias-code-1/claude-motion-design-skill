# STYLE REPORT — code100bug Dialogue Afro (Cartoon Dark Narratif)

- **Identifiant vidéo** : `3dcc772e-da8d-4db5-bdf0-49f7185ff86c`
- **Cluster de style associé** : `cartoon-dark`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 79.1s
- **Nombre de coupes (cuts)** : 4
- **Rythme moyen** : 15.8s par plan

## 2. Palette de Couleurs
- `#1B2A4A (Bleu nuit)`
- `#E74C3C (Rouge)`
- `#2ECC71 (Vert)`
- `#F4A42B (Orange)`

## 3. Typographie
- **Famille recommandée** : DM Sans / Poppins - Gras lisible, sous-titres mot par mot avec pastilles couleur
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Personnages 2D articulés, bulles dialogue, pop emoji, transitions cut nettes

## 5. Sound Design & Narration
- Dialogue multi-voix, musique lofi discrète, SFX bips rétro
