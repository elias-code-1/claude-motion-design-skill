# STYLE REPORT — Mezes Tech 4G/5G (Infographic Bleu / Isométrique)

- **Identifiant vidéo** : `4d1ba867-7232-45d2-af7c-ab7ff2a97abb`
- **Cluster de style associé** : `infographic-bleu`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 171.4s
- **Nombre de coupes (cuts)** : 16
- **Rythme moyen** : 10.1s par plan

## 2. Palette de Couleurs
- `#0D1B3E (Bleu nuit)`
- `#E8E8E0 (Beige clair)`
- `#2563EB (Bleu royal)`
- `#22C55E (Vert)`

## 3. Typographie
- **Famille recommandée** : Plus Jakarta Sans - Medium et Bold, mot-clé surligné dans boîte colorée
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Alternance scènes sombres / claires, schémas isométriques, onglets animés

## 5. Sound Design & Narration
- Voix off narrative posée, SFX clicks précis sur éléments tech
