# STYLE REPORT — Remotion Showreel Teaser (Logo Luxe / Tech)

- **Identifiant vidéo** : `5ce2db81-5057-48ab-9dce-992d07cecef8`
- **Cluster de style associé** : `logo-luxe`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 16:9 (1024x576)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 8.0s
- **Nombre de coupes (cuts)** : 2
- **Rythme moyen** : 2.7s par plan

## 2. Palette de Couleurs
- `#0D0D1A (Fond noir)`
- `#5B21B6 (Violet intense)`
- `#F59E0B (Orange étincelle)`
- `#FFFFFF (Texte)`

## 3. Typographie
- **Famille recommandée** : Syne / Uncut Sans - Titres bold géométriques avec décalage d'accent couleur
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Logo géométrique 3D tournant, révélation éclat lumineux, particules cosmiques

## 5. Sound Design & Narration
- Riser montant + gros impact de basse sub à 3.2s, shimmer de résonance
