# STYLE REPORT — aLance Features 60fps (SaaS Corporate)

- **Identifiant vidéo** : `7ace4ae2-efe1-47c5-a793-28300489e4cf`
- **Cluster de style associé** : `saas-clair-fr`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 16:9 (832x464, 60fps)
- **Cadence (FPS)** : 60.0 fps
- **Durée totale** : 49.1s
- **Nombre de coupes (cuts)** : 4
- **Rythme moyen** : 9.8s par plan

## 2. Palette de Couleurs
- `#F0F4FA (Fond clair)`
- `#2563EB (Bleu)`
- `#111827 (Noir)`

## 3. Typographie
- **Famille recommandée** : Plus Jakarta Sans 800 - Fluidité 60fps
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Animations de cartes ultra fluides, curseurs, transitions sweep

## 5. Sound Design & Narration
- Musique corporate 108 BPM
