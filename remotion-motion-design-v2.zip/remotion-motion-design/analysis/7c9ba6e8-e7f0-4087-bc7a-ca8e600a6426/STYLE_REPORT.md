# STYLE REPORT — Kontra Africa Mobile 9:16 (Illustration Boutique)

- **Identifiant vidéo** : `7c9ba6e8-e7f0-4087-bc7a-ca8e600a6426`
- **Cluster de style associé** : `illustration-boutique`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 59.0s
- **Nombre de coupes (cuts)** : 14
- **Rythme moyen** : 3.9s par plan

## 2. Palette de Couleurs
- `#F0F5F0 (Fond)`
- `#1A5C3A (Vert Kontra)`
- `#F5C518 (Jaune)`
- `#E8792C (Orange alerte)`

## 3. Typographie
- **Famille recommandée** : Plus Jakarta Sans - '84 000 FCFA', 'Dettes clients', noms locaux
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Interface mobile interactive, boutons de relance WhatsApp, badges crédit

## 5. Sound Design & Narration
- SFX pop, clics, voix entraînante
