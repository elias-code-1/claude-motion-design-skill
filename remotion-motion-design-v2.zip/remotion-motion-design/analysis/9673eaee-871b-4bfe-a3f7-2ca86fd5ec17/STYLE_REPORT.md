# STYLE REPORT — aLance Workflow Demo (SaaS Corporate)

- **Identifiant vidéo** : `9673eaee-871b-4bfe-a3f7-2ca86fd5ec17`
- **Cluster de style associé** : `saas-clair-fr`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 16:9 (832x464)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 49.1s
- **Nombre de coupes (cuts)** : 4
- **Rythme moyen** : 9.8s par plan

## 2. Palette de Couleurs
- `#F0F4FA (Fond clair)`
- `#2563EB (Bleu)`
- `#F59E0B (Accent)`
- `#111827 (Noir)`

## 3. Typographie
- **Famille recommandée** : Plus Jakarta Sans 800 - Kinetic words, contrastes forts
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Mockup smartphone flottant, transition cartes 3D, sweep diagonal

## 5. Sound Design & Narration
- Musique tech 108 BPM, ducking prononcé, SFX clicks et notifications
