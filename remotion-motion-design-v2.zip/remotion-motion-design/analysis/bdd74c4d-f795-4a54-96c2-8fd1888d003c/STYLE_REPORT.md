# STYLE REPORT — Cybersec Force Brute (Cartoon Dark)

- **Identifiant vidéo** : `bdd74c4d-f795-4a54-96c2-8fd1888d003c`
- **Cluster de style associé** : `cartoon-dark`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 88.2s
- **Nombre de coupes (cuts)** : 4
- **Rythme moyen** : 17.6s par plan

## 2. Palette de Couleurs
- `#050A14 (Noir tech)`
- `#E74C3C (Rouge alerte)`
- `#F4A42B (Jaune)`
- `#1ABC9C (Cyan)`

## 3. Typographie
- **Famille recommandée** : JetBrains Mono + Inter - Lignes de code terminal et grand titre impact
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Carte du monde clignotante, défilement terminal CLI, radar d'attaque

## 5. Sound Design & Narration
- Sirène douce, clavier tapant, voix off alarmiste mais pédagogique
