# STYLE REPORT — Rémi Sport Football Pixel Art (Storytelling Gaming)

- **Identifiant vidéo** : `e40659c8-fcb8-4151-a9b9-2277de72fb32`
- **Cluster de style associé** : `energie-vert`
- **Niveau de confiance global** : Moyenne (⭐⭐⭐ - format spécifique pixel art)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 80.1s
- **Nombre de coupes (cuts)** : 32
- **Rythme moyen** : 2.4s par plan

## 2. Palette de Couleurs
- `#3A7D35 (Vert gazon)`
- `#E8792C (Orange maillot)`
- `#FFFFFF (Texte)`
- `#1A1A1A (Fond)`

## 3. Typographie
- **Famille recommandée** : Press Start 2P / Changa One - Style pixel gaming ou bold percutant
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Sprite animation 8-bit, coupes très rapides (<3s/plan), flashs d'action

## 5. Sound Design & Narration
- Musique chiptune / gaming énergique, SFX sifflet arbitre, frappe ballon
