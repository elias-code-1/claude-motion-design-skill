# STYLE REPORT — Optisite Digital Slides Carrousel (Infographic Bleu)

- **Identifiant vidéo** : `ef127773-6f49-4b9f-87c9-f04126068383`
- **Cluster de style associé** : `infographic-bleu`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 37.9s
- **Nombre de coupes (cuts)** : 18
- **Rythme moyen** : 2.0s par plan

## 2. Palette de Couleurs
- `#FFFFFF (Fond)`
- `#1B3B8A (Bleu navy)`
- `#5B8DEF (Bleu ciel)`
- `#F0F4FA (Grille)`

## 3. Typographie
- **Famille recommandée** : Inter / Plus Jakarta Sans - Numérotation slide (05/10), titraille majuscule
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Glissement vertical de cartes, barre de progression animée en tête, transitions glissées

## 5. Sound Design & Narration
- Whoosh doux à chaque transition de slide, pas de musique agressive
