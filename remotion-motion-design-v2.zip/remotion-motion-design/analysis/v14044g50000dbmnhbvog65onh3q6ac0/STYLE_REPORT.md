# STYLE REPORT — Mezes Telecom Histoire (Infographic Bleu)

- **Identifiant vidéo** : `v14044g50000dbmnhbvog65onh3q6ac0`
- **Cluster de style associé** : `infographic-bleu`
- **Niveau de confiance global** : Haute (⭐⭐⭐⭐⭐)

## 1. Métadonnées & Montage
- **Résolution & Ratio** : 9:16 (576x1024)
- **Cadence (FPS)** : 30.0 fps
- **Durée totale** : 171.5s
- **Nombre de coupes (cuts)** : 18
- **Rythme moyen** : 9.0s par plan

## 2. Palette de Couleurs
- `#0D1B3E (Sombre)`
- `#E8E8E0 (Beige)`
- `#2563EB (Bleu royal)`

## 3. Typographie
- **Famille recommandée** : Plus Jakarta Sans - Textes explicatifs nets et compacts
- **Hiérarchie** : Titres imposants au-dessus de 72px, corps clair et contrasté.

## 4. Mouvement & Animations
- Déplacement caméra isométrique continu, mise en surbrillance séquentielle

## 5. Sound Design & Narration
- Voix off narrative constante, ponctuation SFX discrets
